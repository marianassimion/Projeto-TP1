# Projeto-TP1
Sistema de cálculo de medicamentos desenvolvido para auxiliar hospitais no gerenciamento de prescrições médicas, controle de dosagens e acompanhamento do histórico de pacientes. 

Este projeto é um sistema de cálculo de medicamentos desenvolvido para auxiliar hospitais no gerenciamento de prescrições médicas, controle de dosagens e acompanhamento do histórico de pacientes. Ele foi projetado para garantir maior segurança e eficiência no cálculo e administração de medicamentos, reduzindo erros humanos e otimizando os processos de prescrição e monitoramento.

Este sistema está sendo desenvolvido por alunos da Universidade de Brasília (UnB) como parte da disciplina Técnicas de Programação 1, utilizando a linguagem Java para implementação dos conceitos aprendidos em sala de aula.

Dionilton Oliveira, Mariana Simion, Rute Alves. 
